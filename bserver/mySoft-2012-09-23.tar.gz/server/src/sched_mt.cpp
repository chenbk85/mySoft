/* sched_mt.cpp
 *
**/
#include "processor.h"
#include "connection.h"
#include "sched_mt.h"
#include "log.h"

int schedule_mt::on_request(MessageRequest* req)
{
	int retval = inq_.put(req, 10);
	return retval;
}

int schedule_mt::response(MessageResponse* rsp)
{
	Connection* conn = NULL; // TODO: get message's connection. how?
	int retval;

	if (conn == NULL /* || !valid() */) {
		SYSLOG_ERROR("response %lu data failed: no connection found by flow-%lu",
				(unsigned long)rsp->tsize(), rsp->flow_);
	}

	retval = conn->response(rsp);
	if (retval < 0) {
		SYSLOG_ERROR("response %lu data to %s failed: %m",
				(unsigned long)rsp->tsize(), conn->name());
		return retval;
	}

	return 0;
}

void* schedule_mt::thread_entry(void *p)
{
	schedule_mt* sched = static_cast<schedule_mt*>(p);
	int tid = 0; // TODO
	return sched->thread_entry(tid);
}

void* schedule_mt::thread_entry(int tid)
{
	while (!is_stopped()) {
		MessageRequest* req = inq_.get(100);
		if (req == NULL) {
			continue;
		}

		MessageResponse* rsp = NULL;
		int retval = proc()->process(tid, *req, rsp);
		
		if (retval < 0) {
			assert(rsp != NULL);
			SYSLOG_ERROR("prcess failed: %m");
			// ignore it
		}
		else if (rsp != NULL) {
			retval = response(rsp);
			if (retval < 0) {
				SYSLOG_ERROR("response failed: %d", errno);
			}
		}
		else {
			// no response here
			// skip
		}
	}
	
	return NULL;
}

class MtScheduleFactory : public ScheduleFactory {
public:
	schedule* create(processor* proc, const std::map<std::string, std::string>& params)
	{
		int tcnt = 10;
		schedule* sched = new schedule_mt(tcnt, proc);
		return sched;
	}
	
	void destroy(schedule* sched)
	{
		try {
			schedule_mt* s = dynamic_cast<schedule_mt *>(sched);
			delete s;
		}
		catch (std::exception& ex) {
			// TODO:
		}
	}
};

static MtScheduleFactory sf;
//static void _register(void) __attribute__((constructor));
//static void unregister(void) __attribute__((destructor));

void schedule_mt::_register(void)
{
	ScheduleFactory::_register("mt", &sf);
}

void schedule_mt::unregister(void)
{
	ScheduleFactory::unregister("mt");
}

