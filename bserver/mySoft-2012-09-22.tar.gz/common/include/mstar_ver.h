#ifndef _MSTAR_VER_H_
#define _MSTAR_VER_H_

static const char* short_ver =  "MSS-3.7+MCSS-2.1" __MODULE__;
static const char* long_ver =   "MSS-3.7+MCSS-2.1-20120720" __MODULE__ "\n"
"Compiled by " __USER__ "@" __HOST__ " with GCC" __VERSION__ " at " __DATE__ " " __TIME__;

#endif
