#ifndef _OSS_VER_H_
#define _OSS_VER_H_

static const char* short_ver =  "OSS-3.3.0" __MODULE__; 
static const char* long_ver =   "OSS-3.3.0-20120302" __MODULE__ "\n"
"Compiled by " __USER__ "@" __HOST__ " with GCC" __VERSION__ " at " __DATE__ " " __TIME__;

#endif
