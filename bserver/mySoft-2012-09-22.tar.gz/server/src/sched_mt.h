#ifndef __SCHED_MT__H
#define __SCHED_MT__H

#include "processor.h"
#include "message_block.h"
#include "message_queue.hpp"
#include "schedule.h"

class schedule_mt : public schedule {
public:
	schedule_mt(int tcnt, processor* proc)
		: schedule(proc), tcnt_(tcnt), inq_(-1), outq_(-1)
	{
		// TODO:
	}
	virtual ~schedule_mt()
	{
		// TODO:
	}
public:
	static void* thread_entry(void *p);
	void* thread_entry(int tid);
public:
	int on_request(MessageRequest* req);
	int response(MessageResponse* rsp);
private:
	int tcnt_;
	MessageQueue<MessageRequest> inq_;
	MessageQueue<MessageResponse> outq_;
};

#endif /*! __SCHED_MT__H */
