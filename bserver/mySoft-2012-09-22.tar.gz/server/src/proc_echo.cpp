#include <stdexcept>

#include "processor.h"
#include "log.h"

class proc_echo : public processor {
public:
	virtual int init();
	virtual void fini();
	virtual int process(int tid, MessageRequest& req, MessageResponse*& rsp);
};

int proc_echo::init()
{
	return 0;
}

void proc_echo::fini()
{
	//
}

int proc_echo::process(int tid, MessageRequest& req, MessageResponse*& rsp)
{
	return 0;
}

extern "C" processor* create()
{
	try {
		processor* proc = new proc_echo();
		return proc;
	}
	catch (std::exception& ex)
	{
		SYSLOG_ERROR("create failed: %s", ex.what());
	}

	return NULL;
}

extern "C" int destroy(processor* proc)
{
	try {
		proc_echo* eproc = dynamic_cast<proc_echo *>(proc);
		if (eproc != NULL) {
			delete eproc;
			return 0;
		}
	}
	catch (std::exception& ex)
	{
		SYSLOG_ERROR("destroy failed: %s", ex.what());
	}

	return -1;
}

